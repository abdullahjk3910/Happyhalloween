# Happyhalloween.com

เว็บไซต์ Halloween สำหรับ QR Code:
- อ่านบัตร Halloween
- คอมเมนต์จริงจากผู้เข้าชม
- แชร์สถานที่เที่ยว Halloween
- รองรับมือถือ/TikTok

## เปิดคอมเมนต์จริง
1. สร้างโปรเจกต์บน Supabase
2. เปิด SQL Editor แล้วรัน `supabase.sql`
3. ไปที่ Project Settings > API
4. คัดลอก Project URL และ anon/publishable key
5. ใส่ลงใน `app.js`
6. อัปโหลดไฟล์ทั้งหมดขึ้นโฮสต์

หมายเหตุ: `Happyhalloween.com` ต้องจดโดเมนและตั้ง DNS/hosting แยกต่างหาก เว็บไซต์ในชุดนี้ยังไม่สามารถจดโดเมนแทนคุณได้
