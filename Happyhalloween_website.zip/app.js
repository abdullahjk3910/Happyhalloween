// ใส่ค่าจาก Supabase ของคุณตรงนี้
const SUPABASE_URL = "YOUR_SUPABASE_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";

const configured = !SUPABASE_URL.startsWith("YOUR_") && !SUPABASE_ANON_KEY.startsWith("YOUR_");
const db = configured ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const esc = (s) => String(s).replace(/[&<>"']/g, c => ({
  "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
}[c]));

function setStatus(id, text){ document.getElementById(id).textContent = text; }

async function loadComments(){
  const box = document.getElementById("commentList");
  if(!db){ box.innerHTML = '<div class="empty">เว็บไซต์พร้อมแล้ว — ใส่ค่า Supabase ใน app.js เพื่อเปิดคอมเมนต์จริง</div>'; return; }
  const {data,error} = await db.from("comments").select("*").order("created_at",{ascending:false}).limit(100);
  if(error){ box.innerHTML = '<div class="empty">โหลดความคิดเห็นไม่ได้</div>'; return; }
  box.innerHTML = data.length ? data.map(x =>
    `<article class="comment"><strong>${esc(x.name)}</strong><time>${new Date(x.created_at).toLocaleString("th-TH")}</time><div>${esc(x.comment)}</div></article>`
  ).join("") : '<div class="empty">ยังไม่มีความคิดเห็น — มาเป็นคนแรกกัน! 👻</div>';
}

async function loadPlaces(){
  const box = document.getElementById("placeList");
  if(!db){ box.innerHTML = '<div class="empty">ใส่ค่า Supabase เพื่อเปิดระบบแชร์สถานที่จริง</div>'; return; }
  const {data,error} = await db.from("places").select("*").order("created_at",{ascending:false}).limit(100);
  if(error){ box.innerHTML = '<div class="empty">โหลดสถานที่ไม่ได้</div>'; return; }
  box.innerHTML = data.length ? data.map(x =>
    `<article class="place"><strong>📍 ${esc(x.name)}</strong><div>${esc(x.detail)}</div></article>`
  ).join("") : '<div class="empty">ยังไม่มีสถานที่ที่แชร์</div>';
}

document.getElementById("commentForm").addEventListener("submit", async e=>{
  e.preventDefault();
  if(!db){ setStatus("status","ต้องตั้งค่า Supabase ก่อนครับ"); return; }
  const name = document.getElementById("name").value.trim();
  const comment = document.getElementById("comment").value.trim();
  if(!name || !comment) return;
  setStatus("status","กำลังโพสต์...");
  const {error} = await db.from("comments").insert({name,comment});
  if(error){ setStatus("status","โพสต์ไม่สำเร็จ"); return; }
  e.target.reset(); setStatus("status","โพสต์แล้ว! 🎃"); loadComments();
});

document.getElementById("placeForm").addEventListener("submit", async e=>{
  e.preventDefault();
  if(!db){ setStatus("placeStatus","ต้องตั้งค่า Supabase ก่อนครับ"); return; }
  const name = document.getElementById("placeName").value.trim();
  const detail = document.getElementById("placeDetail").value.trim();
  if(!name || !detail) return;
  setStatus("placeStatus","กำลังแชร์...");
  const {error} = await db.from("places").insert({name,detail});
  if(error){ setStatus("placeStatus","แชร์ไม่สำเร็จ"); return; }
  e.target.reset(); setStatus("placeStatus","แชร์แล้ว! 🦇"); loadPlaces();
});

loadComments();
loadPlaces();
